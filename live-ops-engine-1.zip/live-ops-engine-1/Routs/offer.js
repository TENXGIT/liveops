const express=require("express")
const router=express.Router()
const jwt=require("jsonwebtoken")
const secrate="bharathkotthare"
const {offer}=require("../schemas/offer-schema");

const getuserbytoken=(token)=>{
   return new Promise((resolve,reject)=>{
         if(token){
            let userdata
            try{
                const userdata=jwt.verify(token,secrate);
                resolve(userdata);
            }catch(err){
                reject ("invalide token")
            }
         }else{
            reject("token not found")
         }
    })
}
router.post("/list",async(req,res)=>{
    offer.find().then((offers)=>{
        
         offers.filter((offer)=>{
            const rules=offer.target.split("and")
          rules.forEach((rule)=>{
                  let rulekey={}
                  if(rule.includes(">")){
                    rulekey={key:rule.trim().split(">")[0].trim(),value:parseInt(rule.trim().split(">")[1])}
                    if(req.body[rulekey.key]>rulekey.value){
                        validoffers.push(offer)
                    }
                  }else{
                    rulekey={key:rule.trim().split("<")[0],value:rule.trim().split("<")[1]}
                    if(req.body[rulekey.key]<rulekey.value){
                    validoffers.push(offer)
                }
                  }
                
          })
          res.status(200).send(validoffers);
    }).catch(()=>{
        res.status(500).send("internal servar error")
    })
});

router.post("/create",async(req,res)=>{
          getuserbytoken(req.headers.authorization).then((user)=>{
            const offerdata={...req.body}
            offer.create({...req.body,username:user.username}).then((offer)=>{
                res.status(400).send(offer)
            }).catch((err)=>{
                res.status(401).send({meaasge:err.message})
            })
             //res.status(200).send(user)
          }).catch((err)=>{
            res.status(400).send(err)
          })
})

router.put("/update",async()=>{
        offer.updateOne("identifier","data")
})
router.delete("/delete",async()=>{
       offer.deleteOne({_id:req.body.id})
})
module.exports=router