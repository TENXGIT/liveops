const express=require("express")
const router=express.Router()
const salt=10
const bcrype=require("bcrypt")
const jwt=require("jsonwebtoken")
const secrate="bharathkotthare"
const {user}=require("../schemas/userschama");



router.post("/signup",async(req,res)=>{
        bcrype.genSalt(salt,(salterr,saltvalue)=>{
             if(salterr){
                res.status(401).send("cant process")
             }
             else{
                bcrype.hash(req.body.password,saltvalue,(hasherr,hashvalue)=>{
                            if(hasherr){
                                res.status(401).send("hash error")
                            }else{
                                user.create({username:req.body.username,password:hashvalue,email:req.body.email,mobile:req.body.mobile})
                            .then((user)=>{res.status(200).send(user)})
                            .catch((err)=>{ res.status(400).send(err.message)})
                            }
                })
             }
        })
        
})

router.post("/signin",async(req,res)=>{
         user.findOne({username:req.body.username})
         .then((user)=>{
                 if(!user){
                    res.status(401).send("user not found")
                 }else{
                    if(!bcrype.compareSync(req.body.password,user.password)){
                        res.status(401).send("invalide password")
                    }else{
                        const token =jwt.sign({id:user._id,username:user.username},secrate);
                        res.status(200).send({message:"user logged in sucessfully",token:token})
                    }
                 }
         }).catch(()=>{

         })
})
module.exports=router