const express=require("express");
const mongoose=require("mongoose");
const bodyparser=require("body-parser");
const userrouts=require("./Routs/user.js");
const offerrouts=require("./Routs/offer.js")
const port= 8080;
const app=express();

mongoose.connect("mongodb://127.0.0.1:27017/user").then(()=>{
    console.log("connected sucessfully");
}).catch((e)=>{
    console.log("cant connect to db"+e)
})
app.use(bodyparser.json())
app.listen(port,()=>{
    console.log("server is running "+" "+port)
})

 app.use("/user",userrouts);
app.use("/offer",offerrouts);
